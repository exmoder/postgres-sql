# этот код демонстрирует работу InfluxDB 
# и имитирует базу данных для хранения показаний температуры 

from influxdb import InfluxDBClient

client = InfluxDBClient(host='localhost', port=8086)

client.create_database('mydb')
client.switch_database('mydb')

data = [
    {
        "measurement": "weather",
        "fields": {
            "temperature": 22.5
        }
    }
]
client.write_points(data)

result = client.query('SELECT * FROM weather')

for point in result.get_points():
    print(f"Temperature: {point['temperature']}")
