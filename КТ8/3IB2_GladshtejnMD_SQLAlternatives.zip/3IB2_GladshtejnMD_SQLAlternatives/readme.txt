----- Инструкция по установке и настройке InfluxDB на Ubuntu -----

1. Установка и настройка InfluxDB

Сначала скачиваем InfluxDB с официального сайта (https://portal.influxdata.com/downloads/), а далее в терминале выполняем следующие команды:

sudo dpkg -i influxdb_1.8.4_amd64.deb
sudo systemctl unmask influxdb
sudo systemctl start influxdb

2. Установка Python и необходимых библиотек

apt-get install python3 -- для установки Python
pip install influxdb -- для установки библиотеки InfluxDB.


Всё готово, мы успешно установили и настроили InfluxDB для использования на Ubuntu.